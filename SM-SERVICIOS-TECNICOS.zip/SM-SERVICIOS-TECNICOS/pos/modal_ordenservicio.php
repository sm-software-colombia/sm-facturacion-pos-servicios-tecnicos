
<form id="guardarDatosServicio" >
<div class="modal fade " id="dataRegisterServicio" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Lista Ordenes de Servicio</h4>
      </div>
      <div class="modal-body">
			<div id="datos_ajax_register"></div>
          <div class="form-group">
            
<input  style="width:20em"   type="text" class="form-control" id="qz" placeholder="Ingresa nombre o codigo del producto que buscas" onkeyup="loadorden(pagez)">
<div id="loaderorden" style="position: absolute; text-align: center; top: 55px;  width: 100%;display:none;"></div><!-- Carga gif animado -->

<div class="outer_ordenservicio"  ></div>
          </div>


      </div>
      <div class="modal-footer">

        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>

      </div>
    </div>
  </div>
</div>
</form>