<header  >

<img src="../pos/img/logo_010419.png" width="300" height="40">
&nbsp&nbsp

<a  href="../pos/">
    <button>POS</button>
  </a> 
  <a  href="../ordenes_servicio/">
    <button>Ordenes de Servicio</button>
  </a> 
  <a  href="../inventario_f/">
    <button>Inventario</button>
  </a> 
  <a  href="../clientes/">
    <button>Clientes</button>
  </a> 

  
  <a   href="../informes/">
    <button>Informes</button>
  </a> 

  <a   href="../configuracion/">
    <button>Configuración</button>
  </a> 
  <a   href="../informes/cierre_caja.php">
    <button>Salir</button>
  </a> 


  <button type="button" class="btn btn-sample btn-sm" data-toggle="modal" data-target="#exampleModal">
  Danos tu opinion
</button>

<a  href="https://sm-software-colombia.github.io/sm/" >
  <img  src="https://sm-software-colombia.github.io/sm/img/factura_electronica.png" style="height:30px; width:500px"  ></a>
</header>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"> <h3>Tu opinión es muy importante para nosotros</h3> </h5>

      </div>
      <div class="modal-body">
      Así mejoramos cada dia con nuevas mejoras y corrección de errores, enviandonos un mensaje  con tu opinion a <a href="mailto:smsoftwarecolombia@gmail.com">smsoftwarecolombia@gmail.com</a> <br><br>
        Siguenos en nuestra <a target="_blank"  href="https://www.instagram.com/smsoftware_col/">red social  Instagram</a> y descarga las nuevas actualizaciones gratuitas del software.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>

      </div>
    </div>
  </div>
</div>