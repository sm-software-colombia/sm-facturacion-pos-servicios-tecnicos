<form id="actualidarDatos11">
<div class="modal fade" id="dataUpdate11" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="" id="exampleModalLabel">Detalles Orden de Servicio</h4>
        <h6 class="" id="exampleModalLabel">Puedes cambiar datos en los campos</h6>
      </div>
      <div class="modal-body">
			<div class="modal-title"></div>
      <div class="modal-cliente"></div>
      <div class="modal-nit"></div>
      <div class="modal-equipo"></div>
      <div class="modal-serial"></div>
          <div class="form-group">
       
          </div>
		      <div class="form-group">
            <label for="moneda" class="control-label">Diagnostico</label>
            
            <textarea   class="form-control" id="diagnostico" name="diagnostico" value="<?echo $row['diagnostico']?>"></textarea>
          </div>
          <div class="form-group">
            <label for="capital" class="control-label">Valor Servicio</label>
            <input type="text" class="form-control" id="valor" name="valor" value="<?echo $row['valor']?>" maxlength="30">
            <input type="hidden" class="form-control" id="id" name="id" value="<?echo $row['id']?>" maxlength="30">
          </div>
          <div class="form-group">
            <label for="capital" class="control-label">Cambiar estado</label>
            <select class="form-select"  id="eactual" name="eactual"  >
  <option value="Diagnosticar"  >Diagnosticar</option>
  <option value="Revisado"   >Revisado</option>
  <option  value="Reparado" >Reparado</option>
  <option  value="Garantia" >Garantia</option>
</select>         </div>
  
          <div id="datos_ajaxt"></div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Actualizar Datos</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>

      </div>
    </div>
  </div>
</div>
</form>